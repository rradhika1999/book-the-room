import 'package:flutter/material.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Book The Room',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MyHomePage(title: 'Flutter Checked Listview'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  List<bool> inputs = new List<bool>();
  @override
  void initState() {
    // TODO: implement initState
    setState(() {
      for(int i=0;i<20;i++){
        inputs.add(true);
      }
    });
  }

  void ItemChange(bool val,int index){
    setState(() {
      inputs[index] = val;
    });
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: new AppBar(
            bottom: TabBar(
              tabs: [
                Tab(text: "Completed", icon: Icon(Icons.done_outline)),
                Tab(text: "Pending", icon: Icon(Icons.access_time)),
              ],
            ),
            title: new Text('Book the Room'),
          ),
          body: TabBarView(
            children: [
              new ListView.builder(
                  itemCount: inputs.length,
                  itemBuilder: (BuildContext context, int index) {
                    return new Card(
                      child: new Container(
                        padding: new EdgeInsets.all(10.0),
                        child: new Column(
                          children: <Widget>[
                            new CheckboxListTile(
                                value: inputs[index],
                                title: new Text('item ${index}'),
                                controlAffinity: ListTileControlAffinity
                                    .leading,
                                onChanged: (bool val) {
                                  ItemChange(val, index);
                                }
                            )
                          ],
                        ),
                      ),
                    );
                  }
              ),
              new ListView.builder(
                  itemCount: inputs.length,
                  itemBuilder: (BuildContext context, int index) {
                    return new Card(
                      child: new Container(
                        padding: new EdgeInsets.all(10.0),
                        child: new Column(
                          children: <Widget>[
                            new CheckboxListTile(
                                value: inputs[index],
                                title: new Text('item ${index}'),
                                controlAffinity: ListTileControlAffinity
                                    .leading,
                                onChanged: (bool val) {
                                  ItemChange(val, index);
                                }
                            )
                          ],
                        ),
                      ),
                    );
                  }
              ),
            ],
          ),
        ),
      ),
    );
  }
}